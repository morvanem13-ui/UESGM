# 🎓 UESGM Website

Site web officiel de l'**Union des Étudiants et Stagiaires Gabonais au Maroc (UESGM)**.

---

## 🛠️ Stack Technique

| Technologie | Version | Rôle |
|---|---|---|
| [Next.js](https://nextjs.org/) | 14 (App Router) | Framework React |
| [TypeScript](https://www.typescriptlang.org/) | 5.x | Typage statique |
| [Tailwind CSS](https://tailwindcss.com/) | 3.x | Styling |
| [shadcn/ui](https://ui.shadcn.com/) | - | Composants UI |
| [Prisma](https://www.prisma.io/) | 5.x | ORM |
| [PostgreSQL](https://www.postgresql.org/) | - | Base de données |
| [Supabase](https://supabase.com/) | - | BaaS (Auth, Storage) |
| [NextAuth.js](https://next-auth.js.org/) | 4.x | Authentification |
| [pnpm](https://pnpm.io/) | 8.x | Gestionnaire de paquets |

---

## 📁 Structure du Projet

```
uesgm-website/
├── app/
│   ├── (public)/           # Pages publiques
│   │   ├── page.tsx        # Accueil
│   │   ├── a-propos/       # À propos
│   │   ├── evenements/     # Événements
│   │   ├── projets/        # Projets
│   │   ├── bibliotheque/   # Bibliothèque
│   │   ├── antennes/       # Antennes régionales
│   │   ├── bureau-executif/# Bureau exécutif
│   │   ├── partenaires/    # Partenaires
│   │   └── contact/        # Contact
│   ├── admin/              # Panel d'administration (protégé)
│   ├── api/                # Routes API Next.js
│   └── login/              # Page de connexion
├── components/
│   ├── ui/                 # Composants shadcn/ui
│   ├── layout/             # Header, Footer
│   ├── sections/           # Sections de page (Hero, Statistics)
│   ├── cards/              # Composants cartes
│   ├── forms/              # Formulaires
│   ├── admin/              # Composants admin
│   └── maps/               # Cartes interactives (Gabon)
├── lib/                    # Utilitaires & configuration
├── prisma/                 # Schéma de base de données
├── public/                 # Assets statiques
├── scripts/                # Scripts utilitaires
├── tests/                  # Tests (Jest + Playwright)
└── types/                  # Types TypeScript
```

---

## 🚀 Installation Locale

### Prérequis

- Node.js >= 20.11
- pnpm >= 8.x (`npm install -g pnpm`)
- PostgreSQL (local ou via Supabase)

### Étapes

```bash
# 1. Cloner le dépôt
git clone https://github.com/<votre-org>/uesgm-website.git
cd uesgm-website

# 2. Installer les dépendances
pnpm install

# 3. Configurer les variables d'environnement
cp .env.example .env
# Modifier .env avec vos valeurs

# 4. Générer le client Prisma
pnpm db:generate

# 5. Pousser le schéma vers la base de données
pnpm db:push

# 6. Lancer le serveur de développement
pnpm dev
```

L'application sera disponible sur [http://localhost:3000](http://localhost:3000).

---

## ⚙️ Variables d'Environnement

Copiez `.env.example` vers `.env` et renseignez les valeurs suivantes :

```env
# Base de données PostgreSQL
DATABASE_URL="postgresql://user:password@host:5432/uesgm_db"

# NextAuth
NEXTAUTH_SECRET="votre_secret_aleatoire"
NEXTAUTH_URL="https://votre-domaine.com"

# Supabase
NEXT_PUBLIC_SUPABASE_URL="https://xxxx.supabase.co"
NEXT_PUBLIC_SUPABASE_ANON_KEY="votre_cle_anon"
SUPABASE_SERVICE_ROLE_KEY="votre_cle_service"

# Email (Nodemailer)
SMTP_HOST="smtp.votrefournisseur.com"
SMTP_PORT="587"
SMTP_USER="votre@email.com"
SMTP_PASS="votre_mot_de_passe"
SMTP_FROM="noreply@uesgm.org"
```

---

## 🌐 Déploiement sur OVH Cloud via GitHub

### 1. Configurer le dépôt GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/<votre-org>/uesgm-website.git
git push -u origin main
```

### 2. Préparer le serveur OVH (VPS ou Cloud)

Sur votre serveur OVH (Ubuntu/Debian recommandé) :

```bash
# Installer Node.js (via NVM)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
nvm install 20
nvm use 20

# Installer pnpm
npm install -g pnpm

# Installer PM2 (gestionnaire de processus)
npm install -g pm2

# Installer Git
apt-get install git -y
```

### 3. Déploiement Manuel (SSH)

```bash
# Sur le serveur OVH
git clone https://github.com/<votre-org>/uesgm-website.git /var/www/uesgm
cd /var/www/uesgm

# Configurer les variables d'environnement
cp .env.example .env
nano .env  # Remplir les valeurs

# Installer et builder
pnpm install
pnpm db:generate
pnpm build

# Lancer avec PM2
pm2 start npm --name "uesgm" -- start
pm2 save
pm2 startup
```

### 4. Déploiement Automatique via GitHub Actions

Créez le fichier `.github/workflows/deploy.yml` dans votre dépôt :

```yaml
name: Deploy to OVH

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - name: Deploy via SSH
        uses: appleboy/ssh-action@master
        with:
          host: ${{ secrets.OVH_HOST }}
          username: ${{ secrets.OVH_USER }}
          key: ${{ secrets.OVH_SSH_KEY }}
          script: |
            cd /var/www/uesgm
            git pull origin main
            pnpm install
            pnpm db:generate
            pnpm build
            pm2 restart uesgm
```

**Secrets GitHub à configurer** (Settings → Secrets → Actions) :
- `OVH_HOST` : IP ou domaine de votre serveur OVH
- `OVH_USER` : Utilisateur SSH (ex: `ubuntu`)
- `OVH_SSH_KEY` : Clé privée SSH

### 5. Configurer Nginx (Reverse Proxy)

```nginx
server {
    listen 80;
    server_name votre-domaine.com www.votre-domaine.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Puis activer HTTPS avec Certbot :

```bash
apt install certbot python3-certbot-nginx -y
certbot --nginx -d votre-domaine.com -d www.votre-domaine.com
```

---

## 📜 Scripts Disponibles

```bash
pnpm dev            # Serveur de développement
pnpm build          # Build de production
pnpm start          # Lancer en production
pnpm lint           # Vérification ESLint
pnpm typecheck      # Vérification TypeScript
pnpm test           # Tests unitaires (Jest)
pnpm test:e2e       # Tests E2E (Playwright)
pnpm db:generate    # Générer client Prisma
pnpm db:push        # Pousser le schéma DB
pnpm db:migrate     # Migrations Prisma
pnpm db:studio      # Interface Prisma Studio
```

---

## 🔐 Sécurité

- Les variables d'environnement ne sont **jamais** committées (`.env` est dans `.gitignore`)
- Le panel admin est protégé par NextAuth.js
- Les uploads sont restreints (`public/uploads/` exclu du dépôt)
- Rate limiting appliqué sur les routes API sensibles

---

## 🤝 Contribution

1. Forker le dépôt
2. Créer une branche : `git checkout -b feature/ma-fonctionnalite`
3. Committer les changements : `git commit -m "feat: description"`
4. Pousser : `git push origin feature/ma-fonctionnalite`
5. Ouvrir une Pull Request

---

## 📄 Licence

Projet propriétaire — UESGM © 2024. Tous droits réservés.

---

## 🎮 Easter Egg

Un Easter Egg est caché sur le site. Essayez le code suivant depuis n'importe quelle page :
`↑ ↑ ↓ ↓ ← → ← → B A`
